function generateMealPlan(goal, allergies) {
    return fetch('getMeals.php')
        .then(response => response.json())
        .then(data => {
            // Szűrés cél és allergiák alapján
            const filteredMeals = data.filter(meal => {
                // Szűrés cél szerint
                if (meal.goal !== goal) return false;

                // Allergének szűrése
                if (allergies.length > 0) {
                    const mealAllergens = meal.allergens ? meal.allergens.split(',') : [];
                    return !allergies.some(allergy => mealAllergens.includes(allergy));
                }

                return true;
            });

            // Ételek kategóriák szerint csoportosítása
            const mealPlan = {
                breakfast: filteredMeals.filter(meal => meal.category === 'breakfast'),
                lunch: filteredMeals.filter(meal => meal.category === 'lunch'),
                dinner: filteredMeals.filter(meal => meal.category === 'dinner'),
                snacks: filteredMeals.filter(meal => meal.category === 'snacks'),
            };

            return mealPlan;
        })
        .catch(error => console.error('Hiba az ételek lekérésekor:', error));
}

function handleMealGoalChange() {
    const goal = document.getElementById('mealGoal').value;
    // Additional logic for goal change
}

function displayMealPlan(mealPlan) {
    const mealPlanner = document.getElementById('mealPlanner');
    mealPlanner.innerHTML = `
        <h1>Étkezési Terv</h1>
        <button class="back-button" onclick="showMealPlannerHome()">Vissza a főoldalra</button>
        <div class="meal-category">
            <h2>Reggeli</h2>
            <div class="meal-list" id="breakfastList"></div>
        </div>
        <div class="meal-category">
            <h2>Ebéd</h2>
            <div class="meal-list" id="lunchList"></div>
        </div>
        <div class="meal-category">
            <h2>Vacsora</h2>
            <div class="meal-list" id="dinnerList"></div>
        </div>
        <div class="meal-category">
            <h2>Snack</h2>
            <div class="meal-list" id="snackList"></div>
        </div>
    `;

    // Ételek hozzáadása kategóriák szerint
    addMealsToCategory(mealPlan.breakfast, 'breakfastList');
    addMealsToCategory(mealPlan.lunch, 'lunchList');
    addMealsToCategory(mealPlan.dinner, 'dinnerList');
    addMealsToCategory(mealPlan.snacks, 'snackList');

    // Az oldalsó panel megjelenítése
    document.getElementById('sidePanel').style.display = 'block';
}

function addMealsToCategory(meals, categoryId) {
    const categoryElement = document.getElementById(categoryId);
    meals.forEach(meal => {
        const mealItem = document.createElement('div');
        mealItem.classList.add('meal-item');

        // Ellenőrizd, hogy a meal objektum tartalmazza a szükséges adatokat
        mealItem.innerHTML = `
            <h3>${meal.name}</h3>
            <img src="${meal.image}" alt="${meal.name}" style="width: 100%; max-width: 300px;">
            <p>Kalória: ${meal.calories || 0} kcal</p>
            <p>Fehérje: ${meal.protein || 0} g</p>
            <p>Szénhidrát: ${meal.carbs || 0} g</p>
            <p>Zsír: ${meal.fats || 0} g</p>
            <a href="${meal.recipeLink}" target="_blank">Recept megtekintése</a>
        `;

        categoryElement.appendChild(mealItem);
    });
}

function showMealPlannerHome() {
    document.getElementById('mealPlanner').innerHTML = `
        <h1>Étkezési Terv</h1>
        <form id="mealForm">
            <div class="form-group">
                <label for="mealGoal">Cél:</label>
                <select id="mealGoal" onchange="handleMealGoalChange()">
                    <option value="loseWeight">Fogyás</option>
                    <option value="maintainWeight">Súlytartás</option>
                    <option value="gainMuscle">Izmosodás</option>
                </select>
            </div>
            <div class="form-group">
                <label>Allergiák:</label>
                <div>
                    <input type="checkbox" id="gluten" name="allergies" value="gluten"> Glutén<br>
                    <input type="checkbox" id="lactose" name="allergies" value="lactose"> Laktóz<br>
                    <input type="checkbox" id="nuts" name="allergies" value="nuts"> Diófélék<br>
                    <input type="checkbox" id="fish" name="allergies" value="fish"> Hal<br>
                    <input type="checkbox" id="egg" name="allergies" value="egg"> Tojás<br>
                </div>
            </div>
            <div class="form-group">
                <button type="submit">Étkezési Terv Generálása</button>
            </div>
        </form>
    `;
    document.getElementById('mealForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        const allergies = [];
        formData.getAll('allergies').forEach(allergy => allergies.push(allergy));

        const goal = document.getElementById('mealGoal').value;
        generateMealPlan(goal, allergies).then(displayMealPlan);
    });
}