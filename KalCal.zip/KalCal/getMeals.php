<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include_once('dbvezerlo.php');

try {
    // Initialize the database controller
    $dbvez = new DBVezerlo();

    // Process the request
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['error' => 'Invalid JSON input', 'raw_input' => file_get_contents('php://input')]);
        exit;
    }
    
    $goal = $input['goal'] ?? null;
    $allergens = $input['allergies'] ?? [];

    if (!$goal) {
        echo json_encode(['error' => 'Goal is missing', 'input' => $input]);
        exit;
    }

    // Build the query
    $query = "SELECT * FROM kaloria_szamlalo.meals WHERE goal = :goal";
    $params = [':goal' => $goal];

    // Filter by allergens (modified to work with dot-separated values)
    if (!empty($allergens)) {
        foreach ($allergens as $index => $allergen) {
            $query .= " AND allergens NOT LIKE CONCAT('%', :allergen$index, '%')";
            $params[":allergen$index"] = $allergen;
        }
    }

    // Execute the query using DBVezerlo
    $meals = $dbvez->executeSelectQuery($query, $params);

    // Group meals by category
    $categorizedMeals = [
        'breakfast' => [],
        'lunch' => [],
        'dinner' => [],
        'snacks' => []
    ];
    
    foreach ($meals as $meal) {
        $categorizedMeals[$meal['category']][] = [
            'id' => $meal['id'],
            'name' => $meal['name'],
            'image' => $meal['image'],
            'recipe_link' => $meal['recipe_link'],
            'allergens' => $meal['allergens'],
            'calories' => $meal['calories'],
            'protein' => $meal['protein'],
            'carbs' => $meal['carbs'],
            'fats' => $meal['fats'],
            'category' => $meal['category'],
            'goal' => $meal['goal']
        ];
    }

    if (empty($meals)) {
        echo json_encode([
            'debug' => 'No meals found', 
            'query' => $query, 
            'params' => $params,
            'meals' => $categorizedMeals // Return empty categorized structure
        ]);
    } else {
        echo json_encode(['meals' => $categorizedMeals]);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>