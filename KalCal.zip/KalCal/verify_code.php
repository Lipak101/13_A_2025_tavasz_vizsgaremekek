<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['code'];

    try {
        $stmt = $conn->prepare("SELECT * FROM verification_codes WHERE code = :code AND created_at >= NOW() - INTERVAL 10 MINUTE");
        $stmt->bindParam(':code', $code);
        $stmt->execute();
        $verification = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($verification) {
            echo json_encode(['message' => 'Sikeres bejelentkezés!']);
        } else {
            echo json_encode(['message' => 'Érvénytelen vagy lejárt kód!']);
        }
    } catch (PDOException $e) {
        echo json_encode(['message' => 'Hiba történt a kód ellenőrzése során: ' . $e->getMessage()]);
    }
}
?>