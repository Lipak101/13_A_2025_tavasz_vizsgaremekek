<?php
session_start();


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kaloria_szamlalo";

// Kapcsolódás az adatbázishoz
$conn = new mysqli($servername, $username, $password, $dbname);

// Kapcsolódási hiba ellenőrzése
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Felhasználó törlése
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['user_id']) && is_numeric($_POST['user_id'])) {
        $userId = intval($_POST['user_id']);
        $sql = "DELETE FROM users WHERE id = $userId";

        if ($conn->query($sql) === TRUE) {
            echo "Felhasználó törölve: $userId";
        } else {
            echo "Hiba történt a törlés során: " . $conn->error;
        }
    } else {
        echo "Érvénytelen felhasználó ID.";
    }
}

$conn->close();
?>