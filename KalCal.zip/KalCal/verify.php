<?php
require 'config.php';
header('Content-Type: application/json; charset=utf-8');

try {
    // 1. Beérkezett JSON feldolgozása
    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);

    if (empty($data['email']) || empty($data['verificationCode'])) {
        http_response_code(400);
        echo json_encode(['message' => 'Hiányzó e‑mail vagy hitelesítő kód!']);
        exit;
    }

    $email            = $data['email'];
    $verificationCode = $data['verificationCode'];

    // 2. Adatbázis‑kapcsolat
    $conn = new PDO(
        'mysql:host=localhost;dbname=kaloria_szamlalo;charset=utf8mb4',
        'root',
        '',
        [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
          PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC ]
    );

    // 3. Megnézzük, létezik‑e a pending_users tétel
    $stmt = $conn->prepare(
        'SELECT username, email, password
           FROM pending_users
          WHERE email = :email AND verification_code = :code'
    );
    $stmt->execute([':email' => $email, ':code' => $verificationCode]);

    $user = $stmt->fetch();

    if (!$user) {
        http_response_code(400);
        echo json_encode(['message' => 'Érvénytelen hitelesítő kód vagy e‑mail!']);
        exit;
    }

    // 4. Tranzakcióban áthelyezzük a felhasználót
    $conn->beginTransaction();

    $insert = $conn->prepare(
        'INSERT INTO users (username, email, password, is_verified)
         VALUES (:username, :email, :password, 1)'
    );
    $insert->execute([
        ':username' => $user['username'],
        ':email'    => $user['email'],
        ':password' => $user['password']
    ]);

    $delete = $conn->prepare('DELETE FROM pending_users WHERE email = :email');
    $delete->execute([':email' => $email]);

    $conn->commit();

    echo json_encode(['message' => 'E‑mail sikeresen hitelesítve, fiók létrehozva!']);

} catch (Throwable $e) {
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    http_response_code(500);
    echo json_encode(['message' => 'Szerverhiba: ' . $e->getMessage()]);
}
?>