-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2025 at 11:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kaloria_szamlalo`
--

-- --------------------------------------------------------

--
-- Table structure for table `meals`
--

CREATE TABLE `meals` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `recipe_link` varchar(255) DEFAULT NULL,
  `allergens` varchar(255) DEFAULT NULL,
  `calories` int(11) NOT NULL,
  `protein` int(11) NOT NULL,
  `carbs` int(11) NOT NULL,
  `fats` int(11) NOT NULL,
  `category` enum('breakfast','lunch','dinner','snacks') NOT NULL,
  `goal` enum('loseWeight','maintainWeight','gainMuscle') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `meals`
--

INSERT INTO `meals` (`id`, `name`, `image`, `recipe_link`, `allergens`, `calories`, `protein`, `carbs`, `fats`, `category`, `goal`) VALUES
(1, 'Zabkása gyümölccsel', './kajakepek/zabkasa_gyumolccsel.jpg', 'https://gabykonyha.hu/mindenmentes-reggelik/kivul-belul-gyumolcsos-zabkasa/', 'gluten,nuts', 250, 6, 45, 5, 'breakfast', 'loseWeight'),
(2, 'Smoothie', './kajakepek/smoothie.jpg', 'https://tesztplussz.hu/a-legjobb-smoothie-receptek/', '', 220, 5, 50, 2, 'breakfast', 'loseWeight'),
(3, 'Tojásfehérje omlett', './kajakepek/tojasfeherje_omlett.jpg', 'https://rantotthuswokban.bmintbalazs.com/omlett', 'egg', 150, 12, 2, 10, 'breakfast', 'loseWeight'),
(4, 'Avokádós pirítós', './kajakepek/avokados_piritos.jpg', 'https://blikkruzs.blikk.hu/konyha/dobo-agi-recept-reggeli-avokados-piritos/q7b5h42', 'gluten', 300, 8, 40, 15, 'breakfast', 'loseWeight'),
(5, 'Joghurt gyümölccsel', './kajakepek/joghurt_gyumolccsel.jpg', 'https://www.penzugyiterkep.hu/haztartasi-penzugyek/konyhapenz/gyumolcsos-joghurt-az-egeszsegesebb-mindig-dragabb', 'lactose', 180, 10, 20, 5, 'breakfast', 'loseWeight'),
(6, 'Zabpehely', './kajakepek/zabpehely.jpg', 'https://femina.hu/egeszseg/zabpehely-reggelire/', 'gluten', 250, 6, 45, 5, 'breakfast', 'loseWeight'),
(7, 'Gyümölcssaláta', './kajakepek/gyumolcssalata.jpg', 'https://sobors.hu/receptek/gyumolcssalata-otletek/', '', 100, 2, 25, 0, 'breakfast', 'loseWeight'),
(8, 'Teljes kiőrlésű pirítós', './kajakepek/teljes_kiorlesu_piritos.jpg', 'https://www.mindmegette.hu/egeszseges/vajon-egeszsegesebb-a-piritos-mint-a-sima-kenyer', 'gluten', 150, 5, 30, 2, 'breakfast', 'loseWeight'),
(9, 'Zöld turmix', './kajakepek/zold_turmix.jpg', 'https://tejmentesreceptek.hu/recept/bananos-zold-turmix/', '', 180, 4, 40, 1, 'breakfast', 'loseWeight'),
(10, 'Müzli', './kajakepek/muzli.jpg', 'https://www.gyulaihirlap.hu/148340-a-muzli', 'gluten,nuts', 350, 10, 60, 10, 'breakfast', 'loseWeight'),
(11, 'Zöldséges saláta', './kajakepek/zoldseges_salata.jpg', 'https://www.gillerinsumed.hu/vegyes-zoldsegsalata-olivaval-citromosan-insumed-receptek/', 'gluten', 150, 5, 20, 10, 'lunch', 'loseWeight'),
(12, 'Csirke saláta', './kajakepek/csirke_salata.jpg', 'https://tesco.hu/hello/receptek/csirkesalata/382268/', '', 300, 25, 10, 15, 'lunch', 'loseWeight'),
(13, 'Grillezett zöldségek', './kajakepek/grillezett_zoldsegek.jpg', 'https://www.mindmegette.hu/recept/grillezett-zoldsegek-sutoben', '', 200, 5, 30, 10, 'lunch', 'loseWeight'),
(14, 'Quinoa saláta', './kajakepek/quinoa_salata.jpg', 'https://www.nosalty.hu/recept/mediterran-zoldseges-quinoa-salata', '', 250, 8, 40, 10, 'lunch', 'loseWeight'),
(15, 'Lencse leves', './kajakepek/lencse_leves.jpg', 'https://sobors.hu/receptek/zoldseges-lencseleves-recept/', '', 180, 12, 30, 5, 'lunch', 'loseWeight'),
(16, 'Pulyka wrap', './kajakepek/pulyka_wrap.jpg', 'https://ketkes.com/pulykamelles-wrap-mennyei-fokhagymas-ontettel-es-fustolt-sajttal/', 'gluten', 350, 25, 40, 10, 'lunch', 'loseWeight'),
(17, 'Tonhal saláta', './kajakepek/tonhal_salata.jpg', 'https://www.nosalty.hu/recept/laktato-tonhalsalata', 'fish', 300, 30, 10, 15, 'lunch', 'loseWeight'),
(18, 'Sült tofu', './kajakepek/sult_tofu.jpg', 'https://femina.hu/recept/tofu-elkeszitese/', 'soy', 200, 15, 10, 10, 'lunch', 'loseWeight'),
(19, 'Csicseriborsó saláta', './kajakepek/csicseriborso_salata.jpg', 'https://egy.hu/gasztro/csicseriborso-salata-116178', '', 250, 10, 40, 10, 'lunch', 'loseWeight'),
(20, 'Zöldséges rizs', './kajakepek/zoldseges_rizs.jpg', 'https://sobors.hu/receptek/sult-rizs-nem-csak-koret-foetel-is/', '', 300, 5, 60, 5, 'lunch', 'loseWeight'),
(21, 'Grillcsirke saláta', './kajakepek/grillcsirke_salata.jpg', 'https://okosgrill.hu/recept/fustos-cezar-salata/', '', 350, 30, 10, 20, 'dinner', 'loseWeight'),
(22, 'Sült lazac', './kajakepek/sult_lazac.jpg', 'https://www.dietaline.hu/recept/369/mediterran-lazacfile-vele-sult-zoldsegekkel', 'fish', 400, 35, 0, 25, 'dinner', 'loseWeight'),
(23, 'Zöldséges tészta', './kajakepek/zoldseges_teszta.jpg', 'https://www.receptmuhely.hu/receptek/zoldsegek/219668-edes-savanyu-zoldseges-teszta/', 'gluten', 450, 15, 70, 10, 'dinner', 'loseWeight'),
(24, 'Csirke curry', './kajakepek/csirke_curry.jpg', 'https://sobors.hu/receptek/indiai-curry-csirke-recept/', '', 500, 30, 50, 20, 'dinner', 'loseWeight'),
(25, 'Sült zöldségek', './kajakepek/sult_zoldsegek.jpg', 'https://sobors.hu/receptek/oszi-zoldsegek-sutoben-sutve-recept/', '', 200, 5, 30, 10, 'dinner', 'loseWeight'),
(26, 'Gombás rizs', './kajakepek/gombas_rizs.jpg', 'https://cookpad.com/hu/receptek/1926350-gombas-hagymas-rizs', '', 350, 10, 60, 10, 'dinner', 'loseWeight'),
(27, 'Csirke kebab', './kajakepek/csirke_kebab.jpg', 'https://cookpad.com/hu/receptek/15995823-csirke-kebab', '', 300, 25, 10, 15, 'dinner', 'loseWeight'),
(28, 'Zöldséges omlett', './kajakepek/zoldseges_omlett.jpg', 'https://tesco.hu/hello/receptek/zoldseges-omlett/300118/', 'egg', 250, 15, 5, 20, 'dinner', 'loseWeight'),
(29, 'Sült csirke', './kajakepek/sult_csirke.jpg', 'https://proaktivdirekt.com/magazin/cikk/sutobe-a-csirkevel-3-konnyu-sutoben-sult-csirke-recept', '', 400, 35, 0, 25, 'dinner', 'loseWeight'),
(30, 'Zöldséges quinoa', './kajakepek/zoldseges_quinoa.jpg', 'https://sobors.hu/receptek/tojasos-zoldseges-sult-quinoa-recept/', '', 300, 10, 50, 10, 'dinner', 'loseWeight'),
(31, 'Joghurt gyümölccsel', './kajakepek/joghurt_gyumolccsel.jpg', '', 'lactose', 180, 10, 20, 5, 'snacks', 'loseWeight'),
(32, 'Alma szeletek', './kajakepek/alma_szeletek.jpg', '', '', 50, 0, 14, 0, 'snacks', 'loseWeight'),
(33, 'Mandula', './kajakepek/mandula.jpg', '', 'nuts', 160, 6, 6, 14, 'snacks', 'loseWeight'),
(34, 'Sárgarépa rudak', './kajakepek/sargarepa_rudak.jpg', '', '', 25, 1, 6, 0, 'snacks', 'loseWeight'),
(35, 'Görög joghurt', './kajakepek/gorog_joghurt.jpg', '', 'lactose', 100, 10, 6, 5, 'snacks', 'loseWeight'),
(36, 'Körte szeletek', './kajakepek/korte_szeletek.jpg', '', '', 50, 0, 14, 0, 'snacks', 'loseWeight'),
(37, 'Dió', './kajakepek/dio.jpg', '', 'nuts', 185, 4, 4, 18, 'snacks', 'loseWeight'),
(38, 'Uborka szeletek', './kajakepek/uborka_szeletek.jpg', '', '', 16, 1, 4, 0, 'snacks', 'loseWeight'),
(39, 'Szőlő', './kajakepek/szolo.jpg', '', '', 62, 0, 16, 0, 'snacks', 'loseWeight'),
(40, 'Mogyoróvaj', './kajakepek/mogyorovaj.jpg', '', 'nuts', 190, 8, 6, 16, 'snacks', 'loseWeight'),
(41, 'Tojás rántotta', './kajakepek/tojas_rantotta.jpg', 'https://www.nosalty.hu/recept/tojasrantotta-tejben-vajban', 'egg', 150, 12, 2, 10, 'breakfast', 'maintainWeight'),
(42, 'Smoothie', './kajakepek/smoothie.jpg', 'https://tesztplussz.hu/a-legjobb-smoothie-receptek/', '', 220, 5, 50, 2, 'breakfast', 'maintainWeight'),
(43, 'Avokádós pirítós', './kajakepek/avokados_piritos.jpg', 'https://blikkruzs.blikk.hu/konyha/dobo-agi-recept-reggeli-avokados-piritos/q7b5h42', 'gluten', 300, 8, 40, 15, 'breakfast', 'maintainWeight'),
(44, 'Joghurt gyümölccsel', './kajakepek/joghurt_gyumolccsel.jpg', 'https://www.penzugyiterkep.hu/haztartasi-penzugyek/konyhapenz/gyumolcsos-joghurt-az-egeszsegesebb-mindig-dragabb', 'lactose', 180, 10, 20, 5, 'breakfast', 'maintainWeight'),
(45, 'Zabpehely', './kajakepek/zabpehely.jpg', 'https://femina.hu/egeszseg/zabpehely-reggelire/', 'gluten', 250, 6, 45, 5, 'breakfast', 'maintainWeight'),
(46, 'Gyümölcssaláta', './kajakepek/gyumolcssalata.jpg', 'https://sobors.hu/receptek/gyumolcssalata-otletek/', '', 100, 2, 25, 0, 'breakfast', 'maintainWeight'),
(47, 'Teljes kiőrlésű pirítós', './kajakepek/teljes_kiorlesu_piritos.jpg', 'https://www.mindmegette.hu/egeszseges/vajon-egeszsegesebb-a-piritos-mint-a-sima-kenyer', 'gluten', 150, 5, 30, 2, 'breakfast', 'maintainWeight'),
(48, 'Zöld turmix', './kajakepek/zold_turmix.jpg', 'https://tejmentesreceptek.hu/recept/bananos-zold-turmix/', '', 180, 4, 40, 1, 'breakfast', 'maintainWeight'),
(49, 'Müzli', './kajakepek/muzli.jpg', 'https://www.gyulaihirlap.hu/148340-a-muzli', 'gluten,nuts', 350, 10, 60, 10, 'breakfast', 'maintainWeight'),
(50, 'Protein shake', './kajakepek/protein_shake.jpg', 'https://cookidoo.co.uk/recipes/recipe/en-GB/r706678', 'lactose', 200, 20, 10, 5, 'breakfast', 'maintainWeight'),
(51, 'Csirke rizottó', './kajakepek/csirke_rizotto.jpg', 'https://resr.hu/recept/zoldborsos-csirkerizotto/', '', 400, 30, 50, 10, 'lunch', 'maintainWeight'),
(52, 'Zöldséges saláta', './kajakepek/zoldseges_salata.jpg', 'https://www.gillerinsumed.hu/vegyes-zoldsegsalata-olivaval-citromosan-insumed-receptek/', 'gluten', 150, 5, 20, 10, 'lunch', 'maintainWeight'),
(53, 'Grillezett zöldségek', './kajakepek/grillezett_zoldsegek.jpg', 'https://www.mindmegette.hu/recept/grillezett-zoldsegek-sutoben', '', 200, 5, 30, 10, 'lunch', 'maintainWeight'),
(54, 'Quinoa saláta', './kajakepek/quinoa_salata.jpg', 'https://www.nosalty.hu/recept/mediterran-zoldseges-quinoa-salata', '', 250, 8, 40, 10, 'lunch', 'maintainWeight'),
(55, 'Lencse leves', './kajakepek/lencse_leves.jpg', 'https://sobors.hu/receptek/zoldseges-lencseleves-recept/', '', 180, 12, 30, 5, 'lunch', 'maintainWeight'),
(56, 'Pulyka wrap', './kajakepek/pulyka_wrap.jpg', 'https://ketkes.com/pulykamelles-wrap-mennyei-fokhagymas-ontettel-es-fustolt-sajttal/', 'gluten', 350, 25, 40, 10, 'lunch', 'maintainWeight'),
(57, 'Tonhal saláta', './kajakepek/tonhal_salata.jpg', 'https://www.nosalty.hu/recept/laktato-tonhalsalata', 'fish', 300, 30, 10, 15, 'lunch', 'maintainWeight'),
(58, 'Sült tofu', './kajakepek/sult_tofu.jpg', 'https://femina.hu/recept/tofu-elkeszitese/', 'soy', 200, 15, 10, 10, 'lunch', 'maintainWeight'),
(59, 'Csicseriborsó saláta', './kajakepek/csicseriborso_salata.jpg', 'https://egy.hu/gasztro/csicseriborso-salata-116178', '', 250, 10, 40, 10, 'lunch', 'maintainWeight'),
(60, 'Zöldséges rizs', './kajakepek/zoldseges_rizs.jpg', 'https://sobors.hu/receptek/sult-rizs-nem-csak-koret-foetel-is/', '', 300, 5, 60, 5, 'lunch', 'maintainWeight'),
(61, 'Sült lazac', './kajakepek/sult_lazac.jpg', 'https://www.dietaline.hu/recept/369/mediterran-lazacfile-vele-sult-zoldsegekkel', 'fish', 400, 35, 0, 25, 'dinner', 'maintainWeight'),
(62, 'Grillcsirke saláta', './kajakepek/grillcsirke_salata.jpg', 'https://okosgrill.hu/recept/fustos-cezar-salata/', '', 350, 30, 10, 20, 'dinner', 'maintainWeight'),
(63, 'Zöldséges tészta', './kajakepek/zoldseges_teszta.jpg', 'https://www.receptmuhely.hu/receptek/zoldsegek/219668-edes-savanyu-zoldseges-teszta/', 'gluten', 450, 15, 70, 10, 'dinner', 'maintainWeight'),
(64, 'Csirke curry', './kajakepek/csirke_curry.jpg', 'https://sobors.hu/receptek/indiai-curry-csirke-recept/', '', 500, 30, 50, 20, 'dinner', 'maintainWeight'),
(65, 'Sült zöldségek', './kajakepek/sult_zoldsegek.jpg', 'https://sobors.hu/receptek/oszi-zoldsegek-sutoben-sutve-recept/', '', 200, 5, 30, 10, 'dinner', 'maintainWeight'),
(66, 'Gombás rizs', './kajakepek/gombas_rizs.jpg', 'https://cookpad.com/hu/receptek/1926350-gombas-hagymas-rizs', '', 350, 10, 60, 10, 'dinner', 'maintainWeight'),
(67, 'Csirke kebab', './kajakepek/csirke_kebab.jpg', 'https://cookpad.com/hu/receptek/15995823-csirke-kebab', '', 300, 25, 10, 15, 'dinner', 'maintainWeight'),
(68, 'Zöldséges omlett', './kajakepek/zoldseges_omlett.jpg', 'https://tesco.hu/hello/receptek/zoldseges-omlett/300118/', 'egg', 250, 15, 5, 20, 'dinner', 'maintainWeight'),
(69, 'Sült csirke', './kajakepek/sult_csirke.jpg', 'https://proaktivdirekt.com/magazin/cikk/sutobe-a-csirkevel-3-konnyu-sutoben-sult-csirke-recept', '', 400, 35, 0, 25, 'dinner', 'maintainWeight'),
(70, 'Zöldséges quinoa', './kajakepek/zoldseges_quinoa.jpg', 'https://sobors.hu/receptek/tojasos-zoldseges-sult-quinoa-recept/', '', 300, 10, 50, 10, 'dinner', 'maintainWeight'),
(71, 'Joghurt gyümölccsel', './kajakepek/joghurt_gyumolccsel.jpg', '', 'lactose', 180, 10, 20, 5, 'snacks', 'maintainWeight'),
(72, 'Alma szeletek', './kajakepek/alma_szeletek.jpg', '', '', 50, 0, 14, 0, 'snacks', 'maintainWeight'),
(73, 'Mandula', './kajakepek/mandula.jpg', '', 'nuts', 160, 6, 6, 14, 'snacks', 'maintainWeight'),
(74, 'Sárgarépa rudak', './kajakepek/sargarepa_rudak.jpg', '', '', 25, 1, 6, 0, 'snacks', 'maintainWeight'),
(75, 'Görög joghurt', './kajakepek/gorog_joghurt.jpg', '', 'lactose', 100, 10, 6, 5, 'snacks', 'maintainWeight'),
(76, 'Körte szeletek', './kajakepek/korte_szeletek.jpg', '', '', 50, 0, 14, 0, 'snacks', 'maintainWeight'),
(77, 'Dió', './kajakepek/dio.jpg', '', 'nuts', 185, 4, 4, 18, 'snacks', 'maintainWeight'),
(78, 'Uborka szeletek', './kajakepek/uborka_szeletek.jpg', '', '', 16, 1, 4, 0, 'snacks', 'maintainWeight'),
(79, 'Szőlő', './kajakepek/szolo.jpg', '', '', 62, 0, 16, 0, 'snacks', 'maintainWeight'),
(80, 'Mogyoróvaj', './kajakepek/mogyorovaj.jpg', '', 'nuts', 190, 8, 6, 16, 'snacks', 'maintainWeight'),
(81, 'Protein shake', './kajakepek/protein_shake.jpg', 'https://cookidoo.co.uk/recipes/recipe/en-GB/r706678', 'lactose', 200, 20, 10, 5, 'breakfast', 'gainMuscle'),
(82, 'Tojásrántotta', './kajakepek/tojas_rantotta.jpg', 'https://www.nosalty.hu/recept/tojasrantotta-tejben-vajban', 'egg', 150, 12, 2, 10, 'breakfast', 'gainMuscle'),
(83, 'Zabkása Gyümölccsel', './kajakepek/zabkasa_gyumolccsel.jpg', 'https://gabykonyha.hu/mindenmentes-reggelik/kivul-belul-gyumolcsos-zabkasa/', 'gluten', 250, 6, 45, 5, 'breakfast', 'gainMuscle'),
(84, 'Avokádós pirítós', './kajakepek/avokados_piritos.jpg', 'https://blikkruzs.blikk.hu/konyha/dobo-agi-recept-reggeli-avokados-piritos/q7b5h42', 'gluten', 300, 8, 40, 15, 'breakfast', 'gainMuscle'),
(85, 'Joghurt gyümölccsel', './kajakepek/joghurt_gyumolccsel.jpg', 'https://www.penzugyiterkep.hu/haztartasi-penzugyek/konyhapenz/gyumolcsos-joghurt-az-egeszsegesebb-mindig-dragabb', 'lactose', 180, 10, 20, 5, 'breakfast', 'gainMuscle'),
(86, 'Smoothie', './kajakepek/smoothie.jpg', 'https://tesztplussz.hu/a-legjobb-smoothie-receptek/', '', 220, 5, 50, 2, 'breakfast', 'gainMuscle'),
(87, 'Müzli', './kajakepek/muzli.jpg', 'https://www.gyulaihirlap.hu/148340-a-muzli', 'gluten,nuts', 350, 10, 60, 10, 'breakfast', 'gainMuscle'),
(88, 'Gyümölcssaláta', './kajakepek/gyumolcssalata.jpg', 'https://sobors.hu/receptek/gyumolcssalata-otletek/', '', 100, 2, 25, 0, 'breakfast', 'gainMuscle'),
(89, 'Teljes kiőrlésű pirítós', './kajakepek/teljes_kiorlesu_piritos.jpg', 'https://www.mindmegette.hu/egeszseges/vajon-egeszsegesebb-a-piritos-mint-a-sima-kenyer', 'gluten', 150, 5, 30, 2, 'breakfast', 'gainMuscle'),
(90, 'Zöld turmix', './kajakepek/zold_turmix.jpg', 'https://tejmentesreceptek.hu/recept/bananos-zold-turmix/', '', 180, 4, 40, 1, 'breakfast', 'gainMuscle'),
(91, 'Pulyka steak', './kajakepek/pulyka_steak.jpg', 'https://spatrendonline.hu/outdoor/grill-terasz/fuszeres-pulyka-steak-az-igazi-grillelmeny', '', 300, 25, 0, 20, 'lunch', 'gainMuscle'),
(92, 'Csirke saláta', './kajakepek/csirke_salata.jpg', 'https://tesco.hu/hello/receptek/csirkesalata/382268/', '', 350, 30, 10, 20, 'lunch', 'gainMuscle'),
(93, 'Grillezett zöldségek', './kajakepek/grillezett_zoldsegek.jpg', 'https://www.mindmegette.hu/recept/grillezett-zoldsegek-sutoben', '', 200, 5, 30, 10, 'lunch', 'gainMuscle'),
(94, 'Quinoa saláta', './kajakepek/quinoa_salata.jpg', 'https://www.nosalty.hu/recept/mediterran-zoldseges-quinoa-salata', '', 250, 8, 40, 10, 'lunch', 'gainMuscle'),
(95, 'Lencse leves', './kajakepek/lencse_leves.jpg', 'https://sobors.hu/receptek/zoldseges-lencseleves-recept/', '', 180, 12, 30, 5, 'lunch', 'gainMuscle'),
(96, 'Pulyka wrap', './kajakepek/pulyka_wrap.jpg', 'https://ketkes.com/pulykamelles-wrap-mennyei-fokhagymas-ontettel-es-fustolt-sajttal/', 'gluten', 350, 25, 40, 10, 'lunch', 'gainMuscle'),
(97, 'Tonhal saláta', './kajakepek/tonhal_salata.jpg', 'https://www.nosalty.hu/recept/laktato-tonhalsalata', 'fish', 300, 30, 10, 15, 'lunch', 'gainMuscle'),
(98, 'Sült tofu', './kajakepek/sult_tofu.jpg', 'https://femina.hu/recept/tofu-elkeszitese/', 'soy', 200, 15, 10, 10, 'lunch', 'gainMuscle'),
(99, 'Csicseriborsó saláta', './kajakepek/csicseriborso_salata.jpg', 'https://egy.hu/gasztro/csicseriborso-salata-116178', '', 250, 10, 40, 10, 'lunch', 'gainMuscle'),
(100, 'Zöldséges rizs', './kajakepek/zoldseges_rizs.jpg', 'https://sobors.hu/receptek/sult-rizs-nem-csak-koret-foetel-is/', '', 300, 5, 60, 5, 'lunch', 'gainMuscle'),
(101, 'Marhahúsos tészta', './kajakepek/marhahusos_teszta.jpg', 'https://psicore.wordpress.com/2009/11/21/marhahusos-sult-teszta/', 'gluten', 500, 30, 60, 20, 'dinner', 'gainMuscle'),
(102, 'Grillcsirke saláta', './kajakepek/grillcsirke_salata.jpg', 'https://okosgrill.hu/recept/fustos-cezar-salata/', '', 350, 30, 10, 20, 'dinner', 'gainMuscle'),
(103, 'Sült lazac', './kajakepek/sult_lazac.jpg', 'https://www.dietaline.hu/recept/369/mediterran-lazacfile-vele-sult-zoldsegekkel', 'fish', 400, 35, 0, 25, 'dinner', 'gainMuscle'),
(104, 'Zöldséges tészta', './kajakepek/zoldseges_teszta.jpg', 'https://www.receptmuhely.hu/receptek/zoldsegek/219668-edes-savanyu-zoldseges-teszta/', 'gluten', 450, 15, 70, 10, 'dinner', 'gainMuscle'),
(105, 'Csirke curry', './kajakepek/csirke_curry.jpg', 'https://sobors.hu/receptek/indiai-curry-csirke-recept/', '', 500, 30, 50, 20, 'dinner', 'gainMuscle'),
(106, 'Sült zöldségek', './kajakepek/sult_zoldsegek.jpg', 'https://sobors.hu/receptek/oszi-zoldsegek-sutoben-sutve-recept/', '', 200, 5, 30, 10, 'dinner', 'gainMuscle'),
(107, 'Gombás rizs', './kajakepek/gombas_rizs.jpg', 'https://cookpad.com/hu/receptek/1926350-gombas-hagymas-rizs', '', 350, 10, 60, 10, 'dinner', 'gainMuscle'),
(108, 'Csirke kebab', './kajakepek/csirke_kebab.jpg', 'https://cookpad.com/hu/receptek/15995823-csirke-kebab', '', 300, 25, 10, 15, 'dinner', 'gainMuscle'),
(109, 'Zöldséges omlett', './kajakepek/zoldseges_omlett.jpg', 'https://tesco.hu/hello/receptek/zoldseges-omlett/300118/', 'egg', 250, 15, 5, 20, 'dinner', 'gainMuscle'),
(110, 'Sült csirke', './kajakepek/sult_csirke.jpg', 'https://proaktivdirekt.com/magazin/cikk/sutobe-a-csirkevel-3-konnyu-sutoben-sult-csirke-recept', '', 400, 35, 0, 25, 'dinner', 'gainMuscle'),
(111, 'Joghurt gyümölccsel', './kajakepek/joghurt_gyumolccsel.jpg', '', 'lactose', 180, 10, 20, 5, 'snacks', 'gainMuscle'),
(112, 'Alma szeletek', './kajakepek/alma_szeletek.jpg', '', '', 50, 0, 14, 0, 'snacks', 'gainMuscle'),
(113, 'Mandula', './kajakepek/mandula.jpg', '', 'nuts', 160, 6, 6, 14, 'snacks', 'gainMuscle'),
(114, 'Sárgarépa rudak', './kajakepek/sargarepa_rudak.jpg', '', '', 25, 1, 6, 0, 'snacks', 'gainMuscle'),
(115, 'Görög joghurt', './kajakepek/gorog_joghurt.jpg', '', 'lactose', 100, 10, 6, 5, 'snacks', 'gainMuscle'),
(116, 'Körte szeletek', './kajakepek/korte_szeletek.jpg', '', '', 50, 0, 14, 0, 'snacks', 'gainMuscle'),
(117, 'Dió', './kajakepek/dio.jpg', '', 'nuts', 185, 4, 4, 18, 'snacks', 'gainMuscle'),
(118, 'Uborka szeletek', './kajakepek/uborka_szeletek.jpg', '', '', 16, 1, 4, 0, 'snacks', 'gainMuscle'),
(119, 'Szőlő', './kajakepek/szolo.jpg', '', '', 62, 0, 16, 0, 'snacks', 'gainMuscle'),
(120, 'Mogyoróvaj', './kajakepek/mogyorovaj.jpg', '', 'nuts', 190, 8, 6, 16, 'snacks', 'gainMuscle');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `verification_code` VARCHAR(255) DEFAULT NULL,
  `is_verified` TINYINT(1) DEFAULT 0)
 ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE pending_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    verification_code VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'asd', 'pletnor04@gmail.com', '$2y$10$KiDqa8hWuSNs0eHPFKOugeccdSZGeyP2QzUqBkRYBNO2W.oL7Wlbm');

-- --------------------------------------------------------

--
-- Table structure for table `user_meals`
--

CREATE TABLE `user_meals` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `meal_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `meals`
--
ALTER TABLE `meals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_meals`
--
ALTER TABLE `user_meals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meal_id` (`meal_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `meals`
--
ALTER TABLE `meals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_meals`
--
ALTER TABLE `user_meals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_meals`
--
ALTER TABLE `user_meals`
  ADD CONSTRAINT `user_meals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_meals_ibfk_2` FOREIGN KEY (`meal_id`) REFERENCES `meals` (`id`) ON DELETE CASCADE;
COMMIT;

ALTER TABLE users ADD created_at DATETIME DEFAULT CURRENT_TIMESTAMP;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
