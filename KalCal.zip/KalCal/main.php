
 <?php session_start();

// if (!isset($_SESSION['user_id']) && !isset($_GET['guest'])) {
//     header('Location: index.php');
//     exit();
// }
?>
<!-- <!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Főoldal</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }
        .tab button {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
        }
        .tab button:hover {
            background-color: #ddd;
        }
        .tab button.active {
            background-color: #ccc;
        }
        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }
    </style>
</head>
<body>
    <div class="tab">
        <button class="tablinks" onclick="openTab(event, 'Profil')">Profil</button>
        <button class="tablinks" onclick="openTab(event, 'Kaja')">Kaja</button>
        <button class="tablinks" onclick="openTab(event, 'Edzésterv')">Edzésterv</button>
        <button class="tablinks" onclick="openTab(event, 'Eredmények')">Eredmények</button>
    </div>

    <div id="Profil" class="tabcontent">
        <h2>Profil</h2>
        <p>Itt láthatod a profilod adatait.</p>
    </div>

    <div id="Kaja" class="tabcontent">
        <h2>Kaja</h2>
        <p>Itt kezelheted a napi étrendedet.</p>
    </div>

    <div id="Edzésterv" class="tabcontent">
        <h2>Edzésterv</h2>
        <p>Itt kezelheted az edzéstervedet.</p>
    </div>

    <div id="Eredmények" class="tabcontent">
        <h2>Eredmények</h2>
        <p>Itt láthatod az edzéseid eredményeit.</p>
    </div>

    <script>
        function openTab(evt, tabName) {
            const tabcontent = document.getElementsByClassName("tabcontent");
            for (let i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }

            const tablinks = document.getElementsByClassName("tablinks");
            for (let i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }

            document.getElementById(tabName).style.display = "block";
            evt.currentTarget.className += " active";
        }

        // Alapértelmezettül megnyitjuk a Profil fület
        document.getElementById("Profil").style.display = "block";
        document.getElementsByClassName("tablinks")[0].className += " active";
    </script>
</body>
</html> -->