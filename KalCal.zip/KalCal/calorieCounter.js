function handleGoalChange() {
    const goal = document.getElementById('goal').value;
    const targetWeightGroup = document.getElementById('targetWeightGroup');
    const weight = parseFloat(document.getElementById('weight').value);
    const targetWeightInput = document.getElementById('targetWeight');

    if (goal === 'maintain') {
        targetWeightGroup.style.display = 'none';
    } else {
        targetWeightGroup.style.display = 'block';
        targetWeightInput.value = '';
        targetWeightInput.placeholder = goal === 'lose' ? `Kevesebb, mint ${weight}` : `Több, mint ${weight}`;
        targetWeightInput.setAttribute('min', goal === 'lose' ? '0' : (weight + 0.1).toFixed(1));
        targetWeightInput.setAttribute('max', goal === 'lose' ? (weight - 0.1).toFixed(1) : '');
    }
}

function calculateCalories() {
    const weight = parseFloat(document.getElementById('weight').value);
    const height = parseFloat(document.getElementById('height').value);
    const age = parseInt(document.getElementById('age').value);
    const gender = document.getElementById('gender').value;
    const activity = parseFloat(document.getElementById('activity').value);
    const goal = document.getElementById('goal').value;

    let bmr;

    // BMR számítás férfiakra és nőkre
    if (gender === 'male') {
        bmr = 10 * weight + 6.25 * height - 5 * age + 5;
    } else {
        bmr = 10 * weight + 6.25 * height - 5 * age - 161;
    }

    // Napi kalóriaszükséglet aktivitási szint alapján
    const dailyCalories = bmr * activity;

    // Cél alapján módosítás
    let finalCalories;
    if (goal === 'lose') {
        finalCalories = dailyCalories - 500; // Fogyás
    } else if (goal === 'gain') {
        finalCalories = dailyCalories + 500; // Izmosodás
    } else {
        finalCalories = dailyCalories; // Súlytartás
    }

    // Ellenőrzés, ha kevesebb mint 1500
    if (isNaN(finalCalories) || finalCalories < 1500) {
        document.getElementById('calorieResult').innerText = 'Nem lehetséges';
        alert('A napi kalóriaszükséglet nem lehet kevesebb, mint 1500 kcal!');
    } else {
        document.getElementById('calorieResult').innerText = `${Math.round(finalCalories)} kcal`;
    }
}