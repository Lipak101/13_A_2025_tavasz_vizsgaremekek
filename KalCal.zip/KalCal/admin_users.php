<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kaloria_szamlalo";

// Kapcsolódás az adatbázishoz
$conn = new mysqli($servername, $username, $password, $dbname);

// Kapcsolódási hiba ellenőrzése
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Felhasználók lekérdezése
$sql = "SELECT id, username, email, created_at FROM users";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Felhasználók</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
            text-align: left;
        }
        .delete-btn {
            color: red;
            text-decoration: none;
            font-weight: bold;
            border: none;
            background: none;
            cursor: pointer;
        }
        .logo {
            position: absolute;
            top: 10px;
            left: 10px;
        }
        .logo img {
            height: 50px;
            cursor: pointer;
        }
        h1 {
            margin-top: 100px; /* Növeli a cím távolságát a logótól */
            text-align: center; /* Igazítás középre */
        }
    </style>
    <script>
        function deleteUser(userId) {
            if (confirm("Biztosan törölni szeretnéd ezt a felhasználót?")) {
                const xhr = new XMLHttpRequest();
                xhr.open("POST", "delete_user.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onload = function () {
                    if (xhr.status === 200) {
                        alert(xhr.responseText);
                        location.reload(); // Frissíti az oldalt
                    } else {
                        alert("Hiba történt a törlés során.");
                    }
                };
                xhr.send("user_id=" + userId);
            }
        }
    </script>
</head>
<body>
    <div class="logo">
        <a href="index.php"><img src="KalCal_Logo.png" alt="Kezdőlap"></a>
    </div>
    <h1>Felhasználók listája</h1>
    <table>
        <tr>
            <th>Felhasználónév</th>
            <th>Email</th>
            <th>Regisztráció dátuma</th>
            <th>Törlés</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . htmlspecialchars($row['username']) . "</td>
                        <td>" . htmlspecialchars($row['email']) . "</td>
                        <td>" . htmlspecialchars($row['created_at']) . "</td>
                        <td>
                            <button class='delete-btn' onclick='deleteUser(" . $row['id'] . ")'>X</button>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Nincs adat</td></tr>";
        }
        ?>
    </table>
</body>
</html>
<?php
$conn->close();
?>