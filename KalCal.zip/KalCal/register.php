<?php
require 'config.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // A POST-ból kinyert adatok
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirmPassword'];

        if ($password !== $confirmPassword) {
            echo json_encode(['message' => 'A jelszavak nem egyeznek!']);
            return;
        }

        $conn = new PDO('mysql:host=localhost;dbname=kaloria_szamlalo', 'root', '');
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $verificationCode = bin2hex(random_bytes(16));

        // Beillesztés a pending_users táblába
        $stmt = $conn->prepare("INSERT INTO pending_users (username, email, password, verification_code) VALUES (:username, :email, :password, :verification_code)");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':verification_code', $verificationCode);
        $stmt->execute();

        // PHPMailer a kód küldéséhez
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'kertiocsi@gmail.com'; // Saját Gmail cím
        $mail->Password = 'zgpg zcwu oiex qhvl'; // Gmail alkalmazás jelszó
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('kertiocsi@gmail.com', 'Kalória Számláló');
        $mail->addAddress($email, $username);

        $mail->isHTML(true);
        $mail->Subject = 'Hitelesítő kód';
        $mail->Body = "Kedves $username,<br><br>Kérjük, erősítsd meg az e-mail címedet a következő kóddal:<br><br><strong>$verificationCode</strong><br><br>Köszönjük!";
        $mail->AltBody = "Kedves $username,\n\nKérjük, erősítsd meg az e-mail címedet a következő kóddal:\n\n$verificationCode\n\nKöszönjük!";

        // E-mail küldése
        $mail->send();

        // Válasz küldése a frontendnek
        echo json_encode([
            'message' => 'Ellenőrizd az e-mail fiókodat a hitelesítő kódért.',
            'requiresVerification' => true
        ]);
    }
} catch (PDOException $e) {
    echo json_encode(['message' => 'Adatbázis hiba: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['message' => 'Hiba történt: ' . $e->getMessage()]);
}
?>
