<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KalCal - Kalóriaszámláló</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Fejléc -->
    <header>
        <!-- Logo -->
        <a href="#" class="logo" onclick="goToHome()">
            <img src="KalCal_Logo.png" alt="KalCal Logo">
            KalCal
        </a>

        <!-- Lenyíló menü -->
        <div class="dropdown">
            <button class="menu-button">Menü</button>
            <div class="dropdown-content" id="menuItems">
                <button id="registerButton" onclick="showRegistration()">Regisztráció</button>
                <button id="loginButton" onclick="showLogin()">Bejelentkezés</button>
                <button id="guestButton" onclick="useWithoutLogin()">Folytatás bejelentkezés nélkül</button>
                <button id="logoutButton" onclick="logout()" style="display: none;">Kijelentkezés</button>
                <!-- Admin menüpont -->
                <button id="adminButton" onclick="showAdminPanel()" style="display: none;">Admin Felület</button>
            </div>
        </div>
    </header>

    <!-- Profil sáv -->
    <nav id="profileNav" style="display: none;">
        <ul>
            <li><a href="#" onclick="showProfile()">Profil</a></li>
            <li><a href="#" onclick="showCalorieCounter()">Kalóriaszámoló</a></li>
            <li><a href="#" onclick="showMealPlanner()">Étkezés</a></li>
            <li><a href="#" onclick="showWorkoutPlan()">Edzés</a></li>
        </ul>
    </nav>

    <!-- Fő tartalom -->
    <div class="container" id="intro">
       
       
    <div class="news-grid">
        <div class="news-item">
            <h2>Fogyás</h2>
            <p>
                Elérheted az álomalakodat! Kövesd nyomon a napi kalóriabeviteledet, és érj el fenntartható fogyási eredményeket a KalCal segítségével.
            </p>
        </div>
        <div class="news-item">
            <h2>Súlytartás</h2>
            <p>
                Tartsd meg az elért eredményeidet! A KalCal pontosan kiszámolja a napi kalóriaszükségletedet, hogy könnyedén fenntarthasd a súlyodat.
            </p>
        </div>
        <div class="news-item">
            <h2>Izmosodás</h2>
            <p>
                Építs erőt és izmot! A KalCal segít az edzésterved és a táplálkozási céljaid összehangolásában, hogy hatékonyan fejlődhess.
            </p>
        </div>
    </div>
    <div>
        <h2>További információ</h2>
        <p>
            Ha részletesebb információra van szükséged a KalCal működéséről, vagy szeretnéd megismerni a legújabb funkciókat, akkor regisztrálj be:
        <button class="itt" onclick="showRegistration()">itt</button>

        </p>

    </div>
    </div>

    <!-- Regisztráció űrlap -->
    <div class="container" id="registration" style="display: none;">
        <h1>Regisztráció</h1>
        <form id="registerForm">
            <div class="form-group">
                <label for="regUsername">Felhasználónév:</label><br>
                <input type="text" id="regUsername"  name="username" placeholder="Felhasználónév" required>
            </div>
            <div class="form-group">
                <label for="regEmail">E-mail cím:</label><br>
                <input type="email" id="regEmail" name="email" placeholder="E-mail cím" required>
            </div>
            <div class="form-group">
                <label for="regPassword">Jelszó:</label><br>
                <input type="password" id="regPassword" name="password" placeholder="Jelszó" required>
            </div>
            <div class="form-group">
                <label for="regConfirmPassword">Jelszó megerősítése:</label><br>
                <input type="password" id="regConfirmPassword" name="confirmPassword" placeholder="Jelszó megerősítése" required>
            </div>
            <div class="form-group">
                <button type="submit">Regisztráció</button>
            </div>
        </form>
    </div>

    <!-- Bejelentkezés űrlap -->
    <div class="container" id="login" style="display: none;">
        <h1>Bejelentkezés</h1>
        <form id="loginForm">
            <div class="form-group">
                <label for="loginEmail">E-mail cím:</label><br>
                <input type="email" id="loginEmail" name="email" placeholder="E-mail cím" required>
            </div>
            <div class="form-group">
                <label for="loginPassword">Jelszó:</label><br>
                <input type="password" id="loginPassword" name="password" placeholder="Jelszó" required>
            </div>
            <div class="form-group">
                <button type="submit">Bejelentkezés</button>
            </div>
        </form>
    </div>

    <!-- E-mail hitelesítés -->
    <div class="container" id="verificationModal" style="display: none;">
        <h1>E-mail hitelesítés</h1>
        <!-- <form id="verifyForm" action="verify.php" method="POST"> -->
        <form id="verifyForm">
            <!-- <div class="form-group">
                <label for="verifyEmail">E-mail cím:</label><br>
                <input type="email" id="verifyEmail" name="email" placeholder="E-mail cím" required>
            </div> -->
            <div class="form-group">
                <label for="verifyCode">Hitelesítő kód:</label><br>
                <input type="text" id="verifyCode" name="verificationCode" placeholder="Hitelesítő kód" required>
            </div>
            <div class="form-group">
                <button type="submit">Hitelesítés</button>
            </div>
        </form>
    </div>

    <!-- Fő tartalom (bejelentkezés után) -->
    <div class="container" id="mainContent" style="display: none;">
        <h1>Napi Kalóriaszükséglet Számító</h1>
        <div class="form-group">
            <label for="weight">Testsúly (kg):</label><br>
            <input type="number" id="weight" placeholder="Pl. 70">
        </div>
        <div class="form-group">
            <label for="height">Magasság (cm):</label><br>
            <input type="number" id="height" placeholder="Pl. 175">
        </div>
        <div class="form-group">
            <label for="age">Életkor (év):</label><br>
            <input type="number" id="age" placeholder="Pl. 30">
        </div>
        <div class="form-group">
            <label for="gender">Nem:</label><br>
            <select id="gender">
                <option value="male">Férfi</option>
                <option value="female">Nő</option>
            </select>
        </div>
        <div class="form-group">
            <label for="activity">Aktivitási szint:</label><br>
            <select id="activity">
                <option value="1.2">Minimális aktivitás - Ülő életmód</option>
                <option value="1.375">Könnyű aktivitás - Heti 1-3 edzés</option>
                <option value="1.55">Közepes aktivitás - Heti 3-5 edzés</option>
                <option value="1.725">Magas aktivitás - Heti 6-7 edzés</option>
                <option value="1.9">Nagyon magas aktivitás - Sportolók</option>
            </select>
        </div>
        <div class="form-group">
            <label for="goal">Cél:</label><br>
            <select id="goal" onchange="handleGoalChange()">
                <option value="maintain">Súlyt tartani</option>
                <option value="lose">Fogyni</option>
                <option value="gain">Izmosodni</option>
            </select>
        </div>
        <div class="form-group" id="targetWeightGroup" style="display: none;">
            <label for="targetWeight">Cél testsúly (kg):</label>
            <input type="number" id="targetWeight" placeholder="Add meg a célt">
        </div>
        <div class="form-group">
            <label for="timeframe">Időtartam (hónap):</label><br>
            <input type="number" id="timeframe" placeholder="Pl. 3">
        </div>
        <div class="form-group">
            <button onclick="calculateCalories()">Számítás</button>
        </div>
        <div class="result">
            <p>Napi kalóriaszükséglet: <span id="calorieResult">-</span> kcal</p>
        </div>
    </div>

    <!-- Étkezési opciók -->
    <div class="container" id="mealPlanner" style="display: none;">
        <h1>Étkezési Terv</h1>
        <form id="mealForm">
            <div class="form-group">
                <label for="mealGoal">Cél:</label>
                <select id="mealGoal" name="goal">
                    <option value="loseWeight">Fogyás</option>
                    <option value="maintainWeight">Súlytartás</option>
                    <option value="gainMuscle">Izmosodás</option>
                </select>
            </div>
            <div class="form-group">
                <label><h1>Allergiák:</h1></label>
                <div>
                    <p>Glutén   </p><input type="checkbox" id="gluten" name="allergies" value="gluten"> 
                    <p>Laktóz   </p><input type="checkbox" id="lactose" name="allergies" value="lactose">
                    <p>Diófélék </p><input type="checkbox" id="nuts" name="allergies" value="nuts"> 
                    <p>Hal      </p><input type="checkbox" id="fish" name="allergies" value="fish">
                    <p>Tojás </p>  <input type="checkbox" id="egg" name="allergies" value="egg"> 
                </div>
            </div>
            <div class="form-group">
                <button type="submit">Étkezési Terv Generálása</button>
            </div>
        </form>
    </div>

    <!-- Módosított edzésterv konténer -->
    <div class="container" id="workoutPlan" style="display: none;">
        <h1 class="workout-title">Edzésterv</h1>
        <button class="back-button" onclick="showSection('intro')">
            <i class="fas fa-arrow-left"></i> Vissza
        </button>
        
        <form id="workoutForm">
            <div class="form-group">
                <label for="workoutDays">Edzésnapok száma hetente:</label>
                <select id="workoutDays" name="workoutDays" class="form-control">
                    <option value="">Válassz...</option>
                    <option value="3">3 napos edzésterv</option>
                    <option value="4">4 napos edzésterv</option>
                    <option value="5">5 napos edzésterv</option>
                    <option value="6">6 napos edzésterv</option>
                </select>
            </div>
            <div class="form-group">
                <button type="button" class="btn-primary" onclick="generateWorkoutPlan()">
                    <i class="fas fa-dumbbell"></i> Generálás
                </button>
            </div>
        </form>
        
        <div id="workoutPlanDetails"></div>
    </div>

    <!-- Profil oldal -->
    <div class="container" id="profile" style="display: none;">
        <h1>Profilom</h1>
        
        <div class="profile-container">
            <!-- Bal oldal - Súlykövető -->
            <div class="weight-tracker">
                <h2>Súlykövető</h2>
                <div class="form-group">
                    <label for="currentWeight">Jelenlegi súly (kg):</label>
                    <div style="display: flex; gap: 10px;">
                        <input type="number" id="currentWeight" step="0.1" placeholder="Pl. 75.5">
                        <button onclick="saveWeight()">Mentés</button>
                    </div>
                </div>
                
                <div class="week-container">
                    <h3>Heti súlybevitel</h3>
                    <div class="days-grid">
                        <div class="day-box" data-day="monday">
                            <div class="day-info">
                                <h4>Hétfő</h4>
                                <div class="date-display" id="mondayDate"></div>
                            </div>
                            <input type="number" class="day-input" data-day="monday" step="0.1" placeholder="kg">
                            <div class="weight-display" id="mondayWeight">-</div>
                        </div>
                        <div class="day-box" data-day="tuesday">
                            <div class="day-info">
                                <h4>Kedd</h4>
                                <div class="date-display" id="tuesdayDate"></div>
                            </div>
                            <input type="number" class="day-input" data-day="tuesday" step="0.1" placeholder="kg">
                            <div class="weight-display" id="tuesdayWeight">-</div>
                        </div>
                        <div class="day-box" data-day="wednesday">
                            <div class="day-info">
                                <h4>Szerda</h4>
                                <div class="date-display" id="wednesdayDate"></div>
                            </div>
                            <input type="number" class="day-input" data-day="wednesday" step="0.1" placeholder="kg">
                            <div class="weight-display" id="wednesdayWeight">-</div>
                        </div>
                        <div class="day-box" data-day="thursday">
                            <div class="day-info">
                                <h4>Csütörtök</h4>
                                <div class="date-display" id="thursdayDate"></div>
                            </div>
                            <input type="number" class="day-input" data-day="thursday" step="0.1" placeholder="kg">
                            <div class="weight-display" id="thursdayWeight">-</div>
                        </div>
                        <div class="day-box" data-day="friday">
                            <div class="day-info">
                                <h4>Péntek</h4>
                                <div class="date-display" id="fridayDate"></div>
                            </div>
                            <input type="number" class="day-input" data-day="friday" step="0.1" placeholder="kg">
                            <div class="weight-display" id="fridayWeight">-</div>
                        </div>
                        <div class="day-box" data-day="saturday">
                            <div class="day-info">
                                <h4>Szombat</h4>
                                <div class="date-display" id="saturdayDate"></div>
                            </div>
                            <input type="number" class="day-input" data-day="saturday" step="0.1" placeholder="kg">
                            <div class="weight-display" id="saturdayWeight">-</div>
                        </div>
                        <div class="day-box" data-day="sunday">
                            <div class="day-info">
                                <h4>Vasárnap</h4>
                                <div class="date-display" id="sundayDate"></div>
                            </div>
                            <input type="number" class="day-input" data-day="sunday" step="0.1" placeholder="kg">
                            <div class="weight-display" id="sundayWeight">-</div>
                        </div>
                    </div>
                    <button onclick="saveWeekWeights()" style="margin-top: 10px; width: 100%;">Heti adatok mentése</button>
                </div>
            </div>
            
            <!-- Jobb oldal - Súlytörténet -->
            <div class="weight-history">
                <h2>Súlytörténet</h2>
                <div class="chart-container">
                    <canvas id="weightChart"></canvas>
                </div>
                <div class="history-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Dátum</th>
                                <th>Súly (kg)</th>
                                <th>Változás</th>
                                <th>Összes adat törlése<input type="checkbox" id="selectAll"></th>
                            </tr>
                        </thead>
                        <tbody id="weightHistoryBody">
                            <!-- Ide kerülnek a korábbi súlyadatok -->
                        </tbody>
                    </table>
                    <button onclick="deleteSelectedWeights()" style="margin-top: 10px; width: 100%;">Kijelölt adatok törlése</button>
                </div>
            </div>
        </div>
    </div>

    <!-- chechkthis -->

    <!-- <div id="verificationModal" style="display: none;">
        <div class="modal-content">
            <h2>E-mail hitelesítés</h2>
            <p class="szoveghitelesito">Kérjük, írd be az e-mailben kapott hitelesítő kódot:</p>
            <form id="verificationForm">
                <input type="text" id="verificationCodeInput" placeholder="Hitelesítő kód" required>
                <button type="submit">Hitelesítés</button>
            </form>
            <button onclick="closeVerificationModal()">Mégse</button>
        </div>
    </div> -->

    <script src="meals.js"></script>
    <script src="calorieCounter.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        let registUserEmail = null;

        // Profil oldal funkciók
        let weightHistory = JSON.parse(localStorage.getItem('weightHistory')) || [];
        let weekWeights = JSON.parse(localStorage.getItem('weekWeights')) || {
            monday: null, tuesday: null, wednesday: null,
            thursday: null, friday: null, saturday: null, sunday: null
        };
        let weekDates = JSON.parse(localStorage.getItem('weekDates')) || {};

        if (!window.weightChart) {
            window.weightChart = null;
        }

        function showProfile() {
            try {
                showSection('profile');
                updateWeekDates(); // Frissítjük a dátumokat minden megnyitáskor
                updateWeightDisplay();
                renderWeightHistory();
                renderWeightChart();
            } catch (error) {
                console.error('Hiba a profil megjelenítésekor:', error);
            }
        }

        function updateWeekDates() {
            const today = new Date();
            const currentDay = today.getDay(); // 0-vasárnap, 1-hétfő, ..., 6-szombat
            const currentDate = today.getDate();

            // Kiszámoljuk az aktuális hét napjainak dátumát
            const dates = {};
            const dayNames = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

            for (let i = 0; i < 7; i++) {
                const dayDiff = i - (currentDay === 0 ? 6 : currentDay - 1); // Vasárnapot a hét végére tesszük
                const date = new Date(today);
                date.setDate(currentDate + dayDiff);

                const dayElement = document.getElementById(`${dayNames[i]}Date`);
                const inputElement = document.querySelector(`.day-input[data-day="${dayNames[i]}"]`);

                const dateStr = formatDate(date);
                dates[dayNames[i]] = dateStr;
                dayElement.textContent = dateStr;

                // Ha a dátum a mai napnál későbbi, tiltsuk le az input mezőt
                if (date > today) {
                    inputElement.disabled = true;
                    inputElement.style.opacity = '0.5';
                } else {
                    inputElement.disabled = false;
                    inputElement.style.opacity = '1';
                }
            }

            weekDates = dates;
            localStorage.setItem('weekDates', JSON.stringify(weekDates));
        }

        function formatDate(date) {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }

        function saveWeight() {
            const weightInput = document.getElementById('currentWeight');
            const weight = parseFloat(weightInput.value);
            
            if (isNaN(weight) || weight <= 0) {
                alert('Kérjük, adj meg egy érvényes súlyt!');
                return;
            }
            
            const today = formatDate(new Date());
            saveWeightRecord(today, weight);
            weightInput.value = '';
            alert('Súly sikeresen mentve!');
        }

        function saveWeekWeights() {
            try {
                const dayInputs = document.querySelectorAll('.day-input');
                if (!dayInputs.length) {
                    console.error('Nincsenek napokra vonatkozó bemeneti mezők.');
                    return;
                }

                let hasData = false;

                dayInputs.forEach(input => {
                    const day = input.dataset.day;
                    const value = input.value.trim();
                    const date = weekDates[day];

                    if (value && date) {
                        const weight = parseFloat(value);
                        if (!isNaN(weight) && weight > 0) {
                            weekWeights[day] = weight;
                            saveWeightRecord(date, weight);
                            hasData = true;
                        } else {
                            console.warn(`Érvénytelen súly a(z) ${day} naphoz:`, value);
                        }
                    } else {
                        weekWeights[day] = null;
                    }

                    input.value = '';
                });

                if (hasData) {
                    localStorage.setItem('weekWeights', JSON.stringify(weekWeights));
                    updateWeightDisplay();
                    alert('Heti súlyadatok sikeresen mentve!');
                } else {
                    alert('Nem adtál meg adatokat a mentéshez!');
                }
            } catch (error) {
                console.error('Hiba a heti súlyadatok mentésekor:', error);
            }
        }

        function saveWeightRecord(date, weight) {
            if (!date || isNaN(weight) || weight <= 0) {
                console.error('Érvénytelen dátum vagy súly:', { date, weight });
                return;
            }

            const existingRecordIndex = weightHistory.findIndex(record => record.date === date);

            if (existingRecordIndex >= 0) {
                weightHistory[existingRecordIndex].weight = weight;
            } else {
                weightHistory.unshift({
                    date: date,
                    weight: weight
                });
            }

            localStorage.setItem('weightHistory', JSON.stringify(weightHistory));
            updateWeightDisplay();
            renderWeightHistory();
            renderWeightChart();
        }

        function updateWeightDisplay() {
            // Napok súlyának frissítése
            for (const day in weekWeights) {
                const display = document.getElementById(`${day}Weight`);
                if (weekWeights[day]) {
                    display.textContent = `${weekWeights[day]} kg`;
                    display.style.color = '#4CAF50';
                } else {
                    display.textContent = '-';
                    display.style.color = '#fff';
                }
            }
            
            // Legutóbbi súly megjelenítése
            if (weightHistory.length > 0) {
                document.getElementById('currentWeight').placeholder = `Utoljára: ${weightHistory[0].weight} kg`;
            }
        }

        function renderWeightHistory() {
            const tbody = document.getElementById('weightHistoryBody');
            tbody.innerHTML = '';
            
            if (weightHistory.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4">Nincsenek mentett adatok</td></tr>';
                return;
            }
            
            // Napok sorrendjének növekvő rendezése
            const sortedHistory = weightHistory.sort((a, b) => new Date(a.date) - new Date(b.date));
            
            sortedHistory.forEach((record, index) => {
                const row = document.createElement('tr');
                
                // Jelölőnégyzet
                const checkboxCell = document.createElement('td');
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'delete-checkbox';
                checkbox.dataset.index = index;
                checkboxCell.appendChild(checkbox);
                
                // Dátum
                const dateCell = document.createElement('td');
                dateCell.textContent = record.date;
                
                // Súly
                const weightCell = document.createElement('td');
                weightCell.textContent = `${record.weight} kg`;
                
                // Változás
                const changeCell = document.createElement('td');
                if (index > 0) {
                    const change = record.weight - sortedHistory[index - 1].weight;
                    changeCell.textContent = change > 0 ? `+${change.toFixed(1)} kg` : `${change.toFixed(1)} kg`;
                    
                    if (change < 0) {
                        changeCell.className = 'positive-change';
                    } else if (change > 0) {
                        changeCell.className = 'negative-change';
                    } else {
                        changeCell.className = 'neutral-change';
                    }
                } else {
                    changeCell.textContent = '-';
                    changeCell.className = 'neutral-change';
                }
                
                row.appendChild(checkboxCell);
                row.appendChild(dateCell);
                row.appendChild(weightCell);
                row.appendChild(changeCell);
                tbody.appendChild(row);
            });
        }

        function renderWeightChart() {
            const ctx = document.getElementById('weightChart')?.getContext('2d');
            
            if (!ctx) {
                console.error('A weightChart elem nem található.');
                return;
            }

            // Napok sorrendjének növekvő rendezése
            const sortedHistory = weightHistory.sort((a, b) => new Date(a.date) - new Date(b.date));

            // Csak az utolsó 14 rekord
            const recentHistory = sortedHistory.slice(-14); // Az utolsó 14 rekordot vesszük

            // Ha nincs elég adat, töröljük a chartot
            if (recentHistory.length < 2) {
                if (window.weightChart && typeof window.weightChart.destroy === 'function') {
                    window.weightChart.destroy();
                }
                return;
            }

            const labels = recentHistory.map(record => record.date);
            const data = recentHistory.map(record => record.weight);

            if (window.weightChart && typeof window.weightChart.destroy === 'function') {
                window.weightChart.destroy();
            }

            window.weightChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Súly (kg)',
                        data: data,
                        borderColor: '#2a5298',
                        backgroundColor: 'rgba(42, 82, 152, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return `Súly: ${context.parsed.y} kg`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#fff'
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#fff'
                            }
                        }
                    }
                }
            });
        }

        function deleteSelectedWeights() {
            const checkboxes = document.querySelectorAll('.delete-checkbox:checked');
            const indicesToDelete = Array.from(checkboxes).map(checkbox => parseInt(checkbox.dataset.index));

            if (indicesToDelete.length === 0) {
                alert('Nincs kijelölt adat a törléshez!');
                return;
            }

            // Töröljük a kijelölt elemeket a weightHistory tömbből
            weightHistory = weightHistory.filter((_, index) => !indicesToDelete.includes(index));

            // Frissítjük a helyi tárolót
            localStorage.setItem('weightHistory', JSON.stringify(weightHistory));

            // Frissítjük a táblázatot és a diagramot
            renderWeightHistory();
            renderWeightChart();

            alert('Kijelölt adatok sikeresen törölve!');
        }

        // Profil gomb eseménykezelője
        document.addEventListener('DOMContentLoaded', function () {
            // Select All funkció
            const selectAllCheckbox = document.getElementById('selectAll');
            selectAllCheckbox.addEventListener('change', function () {
                const checkboxes = document.querySelectorAll('.delete-checkbox');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });

            // Egyéb inicializálások
            updateWeekDates();
            const profileLink = document.querySelector('a[onclick="showProfile()"]');
            if (profileLink) {
                profileLink.addEventListener('click', function (e) {
                    e.preventDefault();
                    showProfile();
                });
            }

            // Betöltjük a mentett adatokat
            updateWeightDisplay();
        });

        function showSection(sectionId) {
            // Az összes szekció elrejtése
            const sections = document.querySelectorAll('.container');
            sections.forEach(section => {
                section.style.display = 'none';
            });

            // Csak a kiválasztott szekció megjelenítése
            const selectedSection = document.getElementById(sectionId);
            if (selectedSection) {
                selectedSection.style.display = 'block';
            }
        }

        // Példák a gombokhoz tartozó eseménykezelőkre
        function showRegistration() {
            showSection('registration');
        }

        function showLogin() {
            showSection('login');
        }

        function showCalorieCounter() {
            showSection('mainContent');
        }

        function showMealPlanner() {
            showSection('mealPlanner');
        }

        function showWorkoutPlan() {
            showSection('workoutPlan');
        }

        function goToHome() {
            showSection('intro');
        }

        function useWithoutLogin() {
            showSection('mainContent');
        }

        function showAchievements() {
            showSection('achievements');
        }

        function showAdminPanel() {
            window.location.href = 'admin_users.php';
        }

        document.getElementById('registerForm').addEventListener('submit', function (e) {
    e.preventDefault();  // Megakadályozza az alapértelmezett űrlap elküldést

    const formData = new FormData(this); // Az űrlap adatainak összegyűjtése

    if (formData.get('password') !== formData.get('confirmPassword')) {
        alert('A jelszavak nem egyeznek!');
        return;
    }
    
    registUserEmail = document.getElementById('regEmail').value;
    
    fetch('register.php', {
        method: 'POST',
        body: formData,  // Az űrlap adatokat küldjük POST kéréssel
    })
    .then(response => response.json())  // JSON válasz feldolgozása
    .then(data => {
        alert(data.message);  // Üzenet kiírása

        if (data.requiresVerification) {
            openVerificationModal();  // Ha szükséges a hitelesítés, megjelenítjük a modált
        }
    })
    .catch(error => console.error('Hiba:', error));
});

function openVerificationModal() {
    document.getElementById('verificationModal').style.display = 'flex';
    document.body.classList.add('modal-open');
}

function closeVerificationModal() {
    document.getElementById('verificationModal').style.display = 'none';
    document.body.classList.remove('modal-open');
}


        document.getElementById('loginForm').addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(this);

            fetch('login.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.message === 'Sikeres bejelentkezés!') {
                    // Bejelentkezés utáni elemek megjelenítése
                    showSection('mainContent');
                    document.getElementById('profileNav').style.display = 'block';

                    // Csak a kijelentkezés gomb jelenjen meg a menüben
                    document.getElementById('registerButton').style.display = 'none';
                    document.getElementById('loginButton').style.display = 'none';
                    document.getElementById('guestButton').style.display = 'none';
                    document.getElementById('logoutButton').style.display = 'block';
                    // Ellenőrizd, hogy az admin felhasználó van-e bejelentkezve
                    if (formData.get('email') === 'kertiocsi@gmail.com' ||  formData.get('email') === 'pletnor04@gmail.com'){
                        document.getElementById('adminButton').style.display = 'block';
                    }
                }
            })
            .catch(error => console.error('Hiba:', error));
        });


        document.getElementById('verifyForm').addEventListener('submit', function (e) {
    e.preventDefault();  // Megakadályozza, hogy az űrlap az alapértelmezett módon elküldje a kérelmet

    const formData = new FormData(this);

    const email = registUserEmail;
    const verificationCode = document.getElementById('verifyCode').value;

    // POST kérés küldése a PHP fájlra (verify.php)
    fetch('verify.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, verificationCode })
    })
    .then(res => {
        return res.json();  // JSON válasz feldolgozása
    })
    .then(data => {
        alert(data.message);  // Megjeleníti a válasz üzenetet
        console.log(data); // Nézd meg a válasz objektumot

        if (data.message.includes("sikeresen")) {
            closeVerificationModal();  // Ha sikeres, bezárja a hitelesítési modált

            // További teendők, pl. átirányítás bejelentkezéshez
            // window.location.href = 'login.html';  // Itt átirányíthatod a felhasználót a bejelentkezési oldalra
        }
    })
    .catch(err => {
        console.error('Hiba:', err);  // Hiba kezelése
        alert('Hiba történt! Ellenőrizd a konzolt.');
    });
});

function verifyTestFunc(email_param, verificationCode_param) {
    fetch('verify.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email_param, verificationCode_param })
    })
    .then(res => {
        return res.json();  // JSON válasz feldolgozása
    })
    .then(data => {
        alert(data.message);  // Megjeleníti a válasz üzenetet
        console.log(data); // Nézd meg a válasz objektumot

        if (data.message.includes("sikeresen")) {
            closeVerificationModal();  // Ha sikeres, bezárja a hitelesítési modált

            // További teendők, pl. átirányítás bejelentkezéshez
            // window.location.href = 'login.html';  // Itt átirányíthatod a felhasználót a bejelentkezési oldalra
        }
    })
    .catch(err => {
        console.error('Hiba:', err);  // Hiba kezelése
        alert('Hiba történt! Ellenőrizd a konzolt.');
    });
}

email_paramVar = "kertirajmund@gmail.com";
verificationCode_paramVar = "d16b2edffff12960dfc47b6713e5b197";

// verifyTestFunc(email_paramVar,verificationCode_paramVar);

        function logout() {
            // Elrejtjük a bejelentkezés utáni elemeket
            document.getElementById('profileNav').style.display = 'none';
            showSection('intro');

            // Visszaállítjuk a menü gombjait
            document.getElementById('registerButton').style.display = 'block';
            document.getElementById('loginButton').style.display = 'block';
            document.getElementById('guestButton').style.display = 'block';
            document.getElementById('logoutButton').style.display = 'none';
            document.getElementById('adminButton').style.display = 'none';

            alert('Sikeresen kijelentkeztél!');
        }
    
        // A mealForm eseménykezelőjét külön függvénybe helyezzük
        function setupMealForm() {
            const mealForm = document.getElementById('mealForm');
            if (mealForm) {
                mealForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    const allergies = [];
                    formData.getAll('allergies').forEach(allergy => allergies.push(allergy));
                    const goal = document.getElementById('mealGoal').value;
                    
                    try {
                        const mealPlan = await generateMealPlan(goal, allergies);
                        displayMealPlan(mealPlan);
                    } catch (error) {
                        console.error('Hiba:', error);
                    }
                });
            }
        }

        // Az étkezési terv generálása
        async function generateMealPlan(goal, allergies) {
            console.log('Küldött adatok:', { goal, allergies });
            const response = await fetch('getMeals.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ goal, allergies }),
            });
            
            const data = await response.json();
            console.log('Kapott adatok:', data);
            
            if (data.error) {
                throw new Error(data.error);
            }
            return data.meals || {};
        }

        // Az étkezési terv megjelenítése (módosított változat)
        function displayMealPlan(mealPlan) {
            const mealPlanner = document.getElementById('mealPlanner');
            if (!mealPlanner) return;

            mealPlanner.innerHTML = `
                <h1>Étkezési Terv</h1>
                <button class="back-button" onclick="resetMealPlanner()">Vissza</button>
                <div class="meal-plan-container">
                    ${Object.entries(mealPlan).map(([category, meals]) => `
                        <div class="meal-category">
                            <h2>${category.charAt(0).toUpperCase() + category.slice(1)}</h2>
                            <div class="meal-list">
                                ${meals.map(meal => `
                                    <div class="meal-item">
                                        <h3>${meal.name}</h3>
                                        <img src="${meal.image}" alt="${meal.name}">
                                        <p>Kalória: ${meal.calories} kcal</p>
                                        <p>Fehérje: ${meal.protein} g</p>
                                        <p>Szénhidrát: ${meal.carbs} g</p>
                                        <p>Zsír: ${meal.fats} g</p>
                                        <a href="${meal.recipe_link}" target="_blank">Recept megtekintése</a>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        // Visszaállítás a kezdőképernyőre
        function resetMealPlanner() {
            const mealPlanner = document.getElementById('mealPlanner');
            if (!mealPlanner) return;

            mealPlanner.innerHTML = `
                <h1>Étkezési Terv</h1>
                <form id="mealForm">
                    <div class="form-group">
                        <label for="mealGoal">Cél:</label><br>
                        <select id="mealGoal" name="goal">
                            <option value="loseWeight">Fogyás</option>
                            <option value="maintainWeight">Súlytartás</option>
                            <option value="gainMuscle">Izmosodás</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Allergiák:</label>
                        <div class="allergies">
                            <label><input type="checkbox" name="allergies" value="gluten"> Glutén</label><br>
                            <label><input type="checkbox" name="allergies" value="lactose"> Laktóz</label><br>
                            <label><input type="checkbox" name="allergies" value="nuts"> Diófélék</label><br>
                            <label><input type="checkbox" name="allergies" value="fish"> Hal</label><br>
                            <label><input type="checkbox" name="allergies" value="egg"> Tojás</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit">Étkezési Terv Generálása</button>
                    </div>
                </form>
            `;

            // Újra beállítjuk az eseményfigyelőt
            setupMealForm();
        }

        // Oldal betöltésekor beállítjuk az eseményfigyelőt
        document.addEventListener('DOMContentLoaded', function() {
            setupMealForm();
        });
       
        function generateWorkoutPlan() {
    const days = document.getElementById('workoutDays').value;
    const workoutPlanDetails = document.getElementById('workoutPlanDetails');
    
    if (!days) {
        alert('Kérjük, válassz a lehetőségek közül!');
        return;
    }

    workoutPlanDetails.innerHTML = '';
    
    if (days == 3) {
        workoutPlanDetails.innerHTML = createWorkoutPlan([
            {
                day: 1,
                title: "Push",
                exercises: [
                    { name: "Mellkas nyomás kézi súlyzóval", image: "edzeskepek/push1.jpg.webp", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Fekvőtámasz", image: "edzeskepek/push2.png.png", description: "3 sorozat, amennyit bírsz" },
                    { name: "Váll nyomás", image: "edzeskepek/push3.jpg", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Tricepsz tolódzkodás", image: "edzeskepek/push4.gif.gif", description: "3 sorozat, amennyit bírsz" },
                    { name: "Oldalemelés", image: "edzeskepek/push5.jpg.webp", description: "3 sorozat, 12-15 ismétlés" }
                ]
            },
            {
                day: 2,
                title: "Pull",
                exercises: [
                    { name: "Húzódzkodás", image: "edzeskepek/pull1.jpg", description: "3-4 sorozat, amennyit bírsz" },
                    { name: "Felhúzás", image: "edzeskepek/pull2.jpg", description: "3-4 sorozat, 6-8 ismétlés" },
                    { name: "Bicepsz hajlítás", image: "edzeskepek/pull3.jpg", description: "3 sorozat, 10-12 ismétlés" },
                    { name: "Hátsó váll emelés", image: "edzeskepek/pull4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Hasizom gyakorlat", image: "edzeskepek/pull5.jpg", description: "3 sorozat, 15-20 ismétlés" }
                ]
            },
            {
                day: 3,
                title: "Láb",
                exercises: [
                    { name: "Guggolás", image: "edzeskepek/leg1.jpg.webp", description: "4 sorozat, 8-12 ismétlés" },
                    { name: "Kitörés", image: "edzeskepek/leg2.jpg", description: "3 sorozat, 10-12 ismétlés/láb" },
                    { name: "Lábnyújtás gépen", image: "edzeskepek/leg3.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Lábhajlítás gépen", image: "edzeskepek/leg4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Vádli emelés", image: "edzeskepek/leg5.jpg.webp", description: "4 sorozat, 15-20 ismétlés" }
                ]
            }
        ]);
    } else if (days == 4) {
        workoutPlanDetails.innerHTML = createWorkoutPlan([
            {
                day: 1,
                title: "Push",
                exercises: [
                    { name: "Mellkas nyomás kézi súlyzóval", image: "edzeskepek/push1.jpg.webp", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Fekvőtámasz", image: "edzeskepek/push2.png.png", description: "3 sorozat, amennyit bírsz" },
                    { name: "Váll nyomás", image: "edzeskepek/push3.jpg", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Tricepsz tolódzkodás", image: "edzeskepek/push4.gif.gif", description: "3 sorozat, amennyit bírsz" },
                    { name: "Oldalemelés", image: "edzeskepek/push5.jpg.webp", description: "3 sorozat, 12-15 ismétlés" }
                ]
            },
            {
                day: 2,
                title: "Pull",
                exercises: [
                    { name: "Húzódzkodás", image: "edzeskepek/pull1.jpg", description: "3-4 sorozat, amennyit bírsz" },
                    { name: "Felhúzás", image: "edzeskepek/pull2.jpg", description: "3-4 sorozat, 6-8 ismétlés" },
                    { name: "Bicepsz hajlítás", image: "edzeskepek/pull3.jpg", description: "3 sorozat, 10-12 ismétlés" },
                    { name: "Hátsó váll emelés", image: "edzeskepek/pull4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Hasizom gyakorlat", image: "edzeskepek/pull5.jpg", description: "3 sorozat, 15-20 ismétlés" }
                ]
            },
            {
                day: 3,
                title: "Láb",
                exercises: [
                    { name: "Guggolás", image: "edzeskepek/leg1.jpg.webp", description: "4 sorozat, 8-12 ismétlés" },
                    { name: "Kitörés", image: "edzeskepek/leg2.jpg", description: "3 sorozat, 10-12 ismétlés/láb" },
                    { name: "Lábnyújtás gépen", image: "edzeskepek/leg3.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Lábhajlítás gépen", image: "edzeskepek/leg4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Vádli emelés", image: "edzeskepek/leg5.jpg.webp", description: "4 sorozat, 15-20 ismétlés" }
                ]
            },
            {
                day: 4,
                title: "Kar",
                exercises: [
                    { name: "Bicepsz hajlítás kézi súlyzóval", image: "edzeskepek/arm1.jpg", description: "4 sorozat, 10-12 ismétlés" },
                    { name: "Tricepsz nyújtás kézi súlyzóval", image: "edzeskepek/arm2.jpg.webp", description: "4 sorozat, 10-12 ismétlés" },
                    { name: "Kalapács bicepsz", image: "edzeskepek/arm3.jpg.webp", description: "3 sorozat, 10-12 ismétlés" },
                    { name: "Tricepsz tolódzkodás", image: "edzeskepek/arm4.jpg.webp", description: "3 sorozat, amennyit bírsz" },
                    { name: "Hasizom gyakorlat", image: "edzeskepek/arm5.jpg", description: "3 sorozat, 15-20 ismétlés" }
                ]
            }
        ]);
    } else if (days == 5) {
        workoutPlanDetails.innerHTML = createWorkoutPlan([
            {
                day: 1,
                title: "Push",
                exercises: [
                    { name: "Mellkas nyomás kézi súlyzóval", image: "edzeskepek/push1.jpg.webp", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Fekvőtámasz", image: "edzeskepek/push2.png.png", description: "3 sorozat, amennyit bírsz" },
                    { name: "Váll nyomás", image: "edzeskepek/push3.jpg", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Tricepsz tolódzkodás", image: "edzeskepek/push4.gif.gif", description: "3 sorozat, amennyit bírsz" },
                    { name: "Oldalemelés", image: "edzeskepek/push5.jpg.webp", description: "3 sorozat, 12-15 ismétlés" }
                ]
            },
            {
                day: 2,
                title: "Pull",
                exercises: [
                    { name: "Húzódzkodás", image: "edzeskepek/pull1.jpg", description: "3-4 sorozat, amennyit bírsz" },
                    { name: "Felhúzás", image: "edzeskepek/pull2.jpg", description: "3-4 sorozat, 6-8 ismétlés" },
                    { name: "Bicepsz hajlítás", image: "edzeskepek/pull3.jpg", description: "3 sorozat, 10-12 ismétlés" },
                    { name: "Hátsó váll emelés", image: "edzeskepek/pull4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Hasizom gyakorlat", image: "edzeskepek/pull5.jpg", description: "3 sorozat, 15-20 ismétlés" }
                ]
            },
            {
                day: 3,
                title: "Láb",
                exercises: [
                    { name: "Guggolás", image: "edzeskepek/leg1.jpg.webp", description: "4 sorozat, 8-12 ismétlés" },
                    { name: "Kitörés", image: "edzeskepek/leg2.jpg", description: "3 sorozat, 10-12 ismétlés/láb" },
                    { name: "Lábnyújtás gépen", image: "edzeskepek/leg3.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Lábhajlítás gépen", image: "edzeskepek/leg4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Vádli emelés", image: "edzeskepek/leg5.jpg.webp", description: "4 sorozat, 15-20 ismétlés" }
                ]
            },
            {
                day: 4,
                title: "Kar",
                exercises: [
                    { name: "Bicepsz hajlítás kézi súlyzóval", image: "edzeskepek/arm1.jpg", description: "4 sorozat, 10-12 ismétlés" },
                    { name: "Tricepsz nyújtás kézi súlyzóval", image: "edzeskepek/arm2.jpg.webp", description: "4 sorozat, 10-12 ismétlés" },
                    { name: "Kalapács bicepsz", image: "edzeskepek/arm3.jpg.webp", description: "3 sorozat, 10-12 ismétlés" },
                    { name: "Tricepsz tolódzkodás", image: "edzeskepek/arm4.jpg.webp", description: "3 sorozat, amennyit bírsz" },
                    { name: "Hasizom gyakorlat", image: "edzeskepek/arm5.jpg", description: "3 sorozat, 15-20 ismétlés" }
                ]
            },
            {
                day: 5,
                title: "Váll",
                exercises: [
                    { name: "Váll nyomás kézi súlyzóval", image: "edzeskepek/shoulder1.jpg.webp", description: "4 sorozat, 8-12 ismétlés" },
                    { name: "Oldalemelés", image: "edzeskepek/shoulder2.jpg", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Hátsó váll emelés", image: "edzeskepek/shoulder3.jpg", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Arnold nyomás", image: "edzeskepek/shoulder4.jpg.webp", description: "3 sorozat, 10-12 ismétlés" },
                    { name: "Váll körzés", image: "edzeskepek/shoulder5.jpg.webp", description: "3 sorozat, 15-20 ismétlés" }
                ]
            }
        ]);
    } else if (days == 6) {
        workoutPlanDetails.innerHTML = createWorkoutPlan([
            {
                day: 1,
                title: "Push",
                exercises: [
                    { name: "Mellkas nyomás kézi súlyzóval", image: "edzeskepek/push1.jpg.webp", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Fekvőtámasz", image: "edzeskepek/push2.png.png", description: "3 sorozat, amennyit bírsz" },
                    { name: "Váll nyomás", image: "edzeskepek/push3.jpg", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Tricepsz tolódzkodás", image: "edzeskepek/push4.gif.gif", description: "3 sorozat, amennyit bírsz" },
                    { name: "Oldalemelés", image: "edzeskepek/push5.jpg.webp", description: "3 sorozat, 12-15 ismétlés" }
                ]
            },
            {
                day: 2,
                title: "Pull",
                exercises: [
                    { name: "Húzódzkodás", image: "edzeskepek/pull1.jpg", description: "3-4 sorozat, amennyit bírsz" },
                    { name: "Felhúzás", image: "edzeskepek/pull2.jpg", description: "3-4 sorozat, 6-8 ismétlés" },
                    { name: "Bicepsz hajlítás", image: "edzeskepek/pull3.jpg", description: "3 sorozat, 10-12 ismétlés" },
                    { name: "Hátsó váll emelés", image: "edzeskepek/pull4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Hasizom gyakorlat", image: "edzeskepek/pull5.jpg", description: "3 sorozat, 15-20 ismétlés" }
                ]
            },
            {
                day: 3,
                title: "Láb",
                exercises: [
                    { name: "Guggolás", image: "edzeskepek/leg1.jpg.webp", description: "4 sorozat, 8-12 ismétlés" },
                    { name: "Kitörés", image: "edzeskepek/leg2.jpg", description: "3 sorozat, 10-12 ismétlés/láb" },
                    { name: "Lábnyújtás gépen", image: "edzeskepek/leg3.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Lábhajlítás gépen", image: "edzeskepek/leg4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Vádli emelés", image: "edzeskepek/leg5.jpg.webp", description: "4 sorozat, 15-20 ismétlés" }
                ]
            },
            {
                day: 4,
                title: "Push",
                exercises: [
                    { name: "Mellkas nyomás kézi súlyzóval", image: "edzeskepek/push1.jpg.webp", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Fekvőtámasz", image: "edzeskepek/push2.png.png", description: "3 sorozat, amennyit bírsz" },
                    { name: "Váll nyomás", image: "edzeskepek/push3.jpg", description: "3-4 sorozat, 8-12 ismétlés" },
                    { name: "Tricepsz tolódzkodás", image: "edzeskepek/push4.gif.gif", description: "3 sorozat, amennyit bírsz" },
                    { name: "Oldalemelés", image: "edzeskepek/push5.jpg.webp", description: "3 sorozat, 12-15 ismétlés" }
                ]
            },
            {
                day: 5,
                title: "Pull",
                exercises: [
                    { name: "Húzódzkodás", image: "edzeskepek/pull1.jpg", description: "3-4 sorozat, amennyit bírsz" },
                    { name: "Felhúzás", image: "edzeskepek/pull2.jpg", description: "3-4 sorozat, 6-8 ismétlés" },
                    { name: "Bicepsz hajlítás", image: "edzeskepek/pull3.jpg", description: "3 sorozat, 10-12 ismétlés" },
                    { name: "Hátsó váll emelés", image: "edzeskepek/pull4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Hasizom gyakorlat", image: "edzeskepek/pull5.jpg", description: "3 sorozat, 15-20 ismétlés" }
                ]
            },
            {
                day: 6,
                title: "Láb",
                exercises: [
                    { name: "Guggolás", image: "edzeskepek/leg1.jpg.webp", description: "4 sorozat, 8-12 ismétlés" },
                    { name: "Kitörés", image: "edzeskepek/leg2.jpg", description: "3 sorozat, 10-12 ismétlés/láb" },
                    { name: "Lábnyújtás gépen", image: "edzeskepek/leg3.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Lábhajlítás gépen", image: "edzeskepek/leg4.jpg.webp", description: "3 sorozat, 12-15 ismétlés" },
                    { name: "Vádli emelés", image: "edzeskepek/leg5.jpg.webp", description: "4 sorozat, 15-20 ismétlés" }
                ]
            }
        ]);
    }
}

function createWorkoutPlan(days) {
    let html = '';
    
    days.forEach(day => {
        html += `
            <div class="workout-day">
                <h2>${day.day}. nap: ${day.title}</h2>
                ${day.exercises.map(ex => `
                    <div class="workout-exercise">
                        <img src="${ex.image}" alt="${ex.name}">
                        <div class="workout-exercise-details">
                            <h3>${ex.name}</h3>
                            <p>${ex.description}</p>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    });
    
    

    return html;
}
</script>

</body>
</html>