<?php
require 'config.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Példa felhasználói adatok ellenőrzése
    if ($email === 'asd@asd.com' && $password === 'jelszo') {
        $_SESSION['username'] = 'asdd';
        $_SESSION['email'] = 'asd@asd.com';
        echo json_encode(['message' => 'Sikeres bejelentkezés!']);
    } else {
        try {
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                echo json_encode(['message' => 'Sikeres bejelentkezés!', 'username' => $user['username']]);
            } else {
                echo json_encode(['message' => 'Hibás e-mail cím vagy jelszó!']);
            }
        } catch (PDOException $e) {
            echo json_encode(['message' => 'Hiba történt a bejelentkezés során: ' . $e->getMessage()]);
        }
    }
}
?>